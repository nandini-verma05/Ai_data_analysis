import React from 'react'
import Navbar from '../FrontPage/Navbar'
import ChatBox from '../ChatBoxPage/ChatBox';

const ChatPage = () => {
  return (
    <>
    {/* <Navbar /> */}
    <ChatBox />
    </>
  )
}

export default ChatPage