import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SignUp from '../signup-signin/SignUp'
import OTP from '../signup-signin/otp'
const ChatPage = () => {
  return (
  <div>
    <SignUp />
  
    
  </div>
  )
}

export default ChatPage